package edu.hu.bigdata.e63ScalaSection

object HelloScala {
  def main(args: Array[String]){
    println("Hello CSCIE643 Scala App !!")
  }
}

