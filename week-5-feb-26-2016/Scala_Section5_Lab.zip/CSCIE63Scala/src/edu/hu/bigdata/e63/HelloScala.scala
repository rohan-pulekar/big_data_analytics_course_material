package edu.hu.bigdata.e63

object HelloScala {
  def main(args: Array[String]){
    println("Hello CSCIE643 Scala App !!")
  }
}

